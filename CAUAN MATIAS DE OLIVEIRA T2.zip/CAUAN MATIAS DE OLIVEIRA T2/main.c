#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Noticia.h"
#include "ListaCabCau.h"
#include "ListaEncadeada.h"

int main() {
    Lista minhasNoticias;
    inicializarLista(&minhasNoticias);
    NoListaEncadeada* listaVerificadas = NULL;

    int maiorIdEncontrado = 0;
    carregarListaPendentes(&minhasNoticias, &maiorIdEncontrado);
    carregarListaVerificadas(&listaVerificadas, &maiorIdEncontrado);
    
    definirProximoId(maiorIdEncontrado + 1);

    int op;
    char pchave[200];
    int idnot;

    do {
        printf("\n----------------MENU----------------\n");
        printf("1- Adicionar nova noticia\n");
        printf("2- Remover noticia pendente por ID\n");
        printf("3- Remover noticia verificada por palavra-chave\n");
        printf("4- Buscar noticias pendentes por palavra-chave\n");
        printf("5- Imprimir as noticias\n");
        printf("6- Classificar noticias\n");
        printf("7- Imprimir a quantidade de noticias por categoria\n");
        printf("8- Sair\n");
        printf("Escolha uma opcao:\n");
        printf("------------------------------------\n");
        scanf("%d", &op);
        getchar(); 

        switch(op) {
            case 1: {
                Noticia* nova = criarNoticia();
                if (nova != NULL) {
                    inserirElementoInicio(&minhasNoticias, *nova);
                    free(nova);
                    printf("Noticia adicionada aos pendentes com sucesso!\n");
                }
                break;
            }
            case 2:
                printf("Informe o ID da noticia pendente a ser removida: \n");
                scanf("%d", &idnot);
                getchar();
                removerPendentePorID(&minhasNoticias, idnot);
                break;
            case 3:
                printf("Informe a palavra-chave para remocao: \n");
                fgets(pchave, 200, stdin);
                pchave[strcspn(pchave, "\n")] = '\0';
                removerVerificadaPorPalavraChave(&listaVerificadas, pchave);
                break;
            case 4:
                printf("Informe a palavra-chave para busca em pendentes: \n");
                fgets(pchave, 200, stdin);
                pchave[strcspn(pchave, "\n")] = '\0';
                buscarPendentePorPalavraChave(&minhasNoticias, pchave);
                break;
            case 5: {
                int opImpressao;
                printf("Quais noticias gostaria de imprimir?\n");
                printf("1 - Pendentes\n");
                printf("2 - Verificadas\n");
                printf("3 - Ambas\n");
                printf("Escolha uma opcao: ");
                scanf("%d", &opImpressao);
                getchar();

                if (opImpressao == 1 || opImpressao == 3) {
                    printf("\n---------- NOTICIAS PENDENTES ----------\n");
                    imprimirNoticia(&minhasNoticias);
                }
                if (opImpressao == 2 || opImpressao == 3) {
                    printf("\n---------- NOTICIAS VERIFICADAS ----------\n");
                    imprimirNoticiaVerificada(listaVerificadas);
                }
                if (opImpressao < 1 || opImpressao > 3) {
                    printf("Opcao de impressao invalida.\n");
                }
                break;
            }
            case 6: {
                if (estaVazia(&minhasNoticias)) {
                    printf("Nao ha noticias pendentes para classificar.\n");
                    break;
                }

                NoLista* atual = minhasNoticias.cab->prox;
                while (atual != minhasNoticias.cau) {
                    NoLista* proximoNo = atual->prox; 

                    printf("\n==================================\n");
                    printf("Exibindo Noticia Pendente - ID: %d\n", atual->info.id);
                    printf("Titulo: %s", atual->info.titulo);
                    printf("Conteudo: %s", atual->info.conteudo);
                    printf("Fonte: %s\n", atual->info.fonte);
                    printf("==================================\n");

                    int opcaoClassificar;
                    printf("Como essa noticia sera classificada?\n");
                    printf("1 - Confiavel\n");
                    printf("2 - Suspeita\n");
                    printf("0 - Manter em Analise\n");
                    printf("9 - Parar classificacao (Voltar ao Menu)\n");
                    printf("Escolha: ");
                    scanf("%d", &opcaoClassificar);
                    getchar();

                    if (opcaoClassificar == 9) {
                        break; 
                    }

                    if (opcaoClassificar == 1 || opcaoClassificar == 2) {
                        Noticia* noticiaParaMover = desvincularPendentePorID(&minhasNoticias, atual->info.id);
                        if (noticiaParaMover != NULL) {
                            noticiaParaMover->classificacao = opcaoClassificar;
                            insereNoInicio(&listaVerificadas, noticiaParaMover);
                            printf("Noticia classificada e movida para as verificadas!\n");
                        }
                    } else {
                        printf("Noticia mantida na lista de pendentes (Em Analise).\n");
                    }

                    atual = proximoNo; 
                }
                break;
            }
            case 7:
                printf("\n--- QUANTIDADE ---\n");
                printf("Noticias Pendentes: %d\n", contarPendentes(&minhasNoticias));
                printf("Noticias Confiaveis (Verificadas): %d\n", contarVerificadasPorTipo(listaVerificadas, 1));
                printf("Noticias Suspeitas (Verificadas): %d\n", contarVerificadasPorTipo(listaVerificadas, 2));
                break;
            case 8:
                printf("Salvando banco de dados em arquivos de texto...\n");
                salvarListaPendentes(&minhasNoticias);
                salvarListaVerificadas(listaVerificadas);
                printf("Programa finalizado com sucesso.\n");
                break;
            default:
                printf("Opcao invalida! Tente novamente.\n");
                break;
        } 
    } while(op != 8);

    return 0;
}