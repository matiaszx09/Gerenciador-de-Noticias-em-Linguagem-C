#ifndef LISTAENCADEADA_H
#define LISTAENCADEADA_H
#include "Noticia.h"

typedef struct noListaEncadeada {
    Noticia* info;
    struct noListaEncadeada* prox;
} NoListaEncadeada;

void insereNoInicio(NoListaEncadeada** l, Noticia* v);
void imprimirNoticiaVerificada(NoListaEncadeada* l);
void buscarVerificadaPorPalavraChave(NoListaEncadeada* l, char* palavraBuscaVer);
void removerVerificadaPorPalavraChave(NoListaEncadeada** l, char* palavraRemover);
int contarVerificadasPorTipo(NoListaEncadeada* l, int tipo);
void salvarListaVerificadas(NoListaEncadeada* l);
void carregarListaVerificadas(NoListaEncadeada** l, int* maiorId);

#endif