#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ListaEncadeada.h"

void insereNoInicio(NoListaEncadeada** l, Noticia* v) {
    NoListaEncadeada* novo = (NoListaEncadeada*) malloc(sizeof(NoListaEncadeada));
    if (novo != NULL) {
        novo->info = v;
        novo->prox = *l;
        *l = novo;
    }
}

void imprimirNoticiaVerificada(NoListaEncadeada* l) {
    if (l== NULL) {
        printf("Nenhuma noticia verificada cadastrada.\n");
        return;
    }
    NoListaEncadeada* p;
    for (p = l; p != NULL; p = p->prox) {
        printf("ID: %d\n", p->info->id);
        printf("Data: %d / %d / %d\n", p->info->data.dia, p->info->data.mes, p->info->data.ano);
        printf("Titulo: %s", p->info->titulo);
        printf("Conteudo: %s", p->info->conteudo);
        printf("Fonte: %s\n", p->info->fonte);
        
        if (p->info->classificacao == 1) {
            printf("Classificacao: Confiavel\n");
        } else {
            printf("Classificacao: Suspeita\n");
    }
    }
}

void buscarVerificadaPorPalavraChave(NoListaEncadeada* l, char* palavraBuscaVer) {
    if (l == NULL) {
        printf("A lista de verificadas esta vazia.\n");
        return;
    } 
    NoListaEncadeada* p;
    int achou = 0;
    printf("<RESULTADOS DA BUSCA POR '%s'>\n", palavraBuscaVer);
    for(p = l; p != NULL; p = p->prox) {
        if (strstr(p->info->titulo, palavraBuscaVer) != NULL || strstr(p->info->conteudo, palavraBuscaVer) != NULL) {
            printf("ID: %d\n", p->info->id);
            printf("Titulo: %s", p->info->titulo);
            printf("Conteudo: %s", p->info->conteudo);
            printf("Fonte: %s\n", p->info->fonte);
            achou = 1;
        }
    }
    if (!achou) {
        printf("Nenhuma noticia verificada contem a palavra-chave informada.\n"); 
    }
}

void removerVerificadaPorPalavraChave(NoListaEncadeada** l, char* palavraRemover) {
    if (*l == NULL) {
        printf("A lista de verificadas esta vazia, nao tem o que possa ser removido.\n");
        return;
    }
    NoListaEncadeada* ant, *atu;
    int removido = 0;
    for (atu = *l, ant = NULL; atu != NULL; ) {
        if(strstr(atu->info->titulo, palavraRemover) != NULL || strstr(atu->info->conteudo, palavraRemover) != NULL) {
            NoListaEncadeada* temp = atu;
            if(ant == NULL) {
                *l = atu->prox;
                atu = *l;
            } else {
                ant->prox =atu->prox;
                atu = atu->prox;
            }
            free(temp->info);
            free(temp);
            printf("Noticia contendo '%s' removida das verificadas!\n", palavraRemover);
            removido = 1;
            return;
        } else {
            ant = atu;
            atu = atu->prox;
        }
    }
    if(!removido) {
        printf("Nenhuma noticia com a palavra '%s' foi encontrada para remocao.\n", palavraRemover);
    }
}

int contarVerificadasPorTipo(NoListaEncadeada* l, int tipo) {
    int cont = 0;
    NoListaEncadeada* p;
    for(p = l; p != NULL; p = p->prox) {
        if(p->info->classificacao == tipo) {
            cont++;
        }
    }
    return cont;
}

void salvarListaVerificadas(NoListaEncadeada* l) {
    FILE* f = fopen("verificadas.txt", "w");
    if (f == NULL) return;

    NoListaEncadeada* p;
    for (p = l; p != NULL; p = p->prox) {
        fprintf(f, "%d\n", p->info->id);
        fprintf(f, "%d\n", p->info->classificacao);
        fprintf(f, "%s", p->info->titulo);
        fprintf(f, "%s", p->info->conteudo);
        fprintf(f, "%s", p->info->fonte);
        fprintf(f, "%d %d %d\n", p->info->data.dia, p->info->data.mes, p->info->data.ano);
    }
    fclose(f);
}

void carregarListaVerificadas(NoListaEncadeada** l, int* maiorId) {
    FILE* f = fopen("verificadas.txt", "r");
    if (f == NULL) return;

    int idTemporario;
    while (fscanf(f, "%d\n", &idTemporario) == 1) {
        Noticia* n = (Noticia*) malloc(sizeof(Noticia));
        if (n == NULL) break;

        n->id = idTemporario;
        if (n->id > *maiorId) {
            *maiorId = n->id;
        }
        fscanf(f, "%d\n", &n->classificacao);
        fgets(n->titulo, 200, f);
        fgets(n->conteudo, 5000, f);
        fgets(n->fonte, 200, f);
        fscanf(f, "%d %d %d\n", &n->data.dia, &n->data.mes, &n->data.ano);
        
        insereNoInicio(l, n);
    }
    fclose(f);
}