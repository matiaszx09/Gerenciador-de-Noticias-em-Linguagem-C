#ifndef NOTICIA_H
#define NOTICIA_H

typedef struct data {
    int dia, mes, ano;
} Data;

typedef struct noticia {
    int id, classificacao;
    char titulo[200], conteudo[5000], fonte[200];
    Data data;
} Noticia;

Noticia* criarNoticia();
void definirProximoId(int novoId);

#endif