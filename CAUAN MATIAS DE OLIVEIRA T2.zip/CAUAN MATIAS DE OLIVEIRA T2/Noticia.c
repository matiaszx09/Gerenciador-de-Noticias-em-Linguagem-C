#include <stdio.h>
#include <stdlib.h>
#include "Noticia.h"

int contadorId = 1; 

void definirProximoId(int novoId) {
    contadorId = novoId;
}

Noticia* criarNoticia() {
    Noticia* novo = (Noticia*) malloc(sizeof(Noticia));
    if (novo != NULL) {
        novo->id = contadorId++;
        
        printf("Informe o titulo da noticia: \n");
        fgets(novo->titulo, 200, stdin);
        printf("Informe o conteudo da noticia: \n");
        fgets(novo->conteudo, 5000, stdin);
        printf("Informe a fonte da noticia: \n");
        fgets(novo->fonte, 200, stdin);
        printf("Insira a data de publicacao da noticia (somente numeros, ex: 06 07 2030): \n");
        scanf("%d %d %d", &novo->data.dia, &novo->data.mes, &novo->data.ano);
        getchar();

        novo->classificacao = 0;
    } else {
        printf("Espaco de memoria invalido ou inexistente.\n");
        return NULL;
    }
    return novo;
}