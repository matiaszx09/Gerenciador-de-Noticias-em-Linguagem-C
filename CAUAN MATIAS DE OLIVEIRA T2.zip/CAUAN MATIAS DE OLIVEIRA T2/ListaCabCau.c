#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ListaCabCau.h"

int estaVazia(Lista* l) {
    return (l->cab->prox == l->cau);
}

void inicializarLista(Lista* l) {
    l->cab = (NoLista*) malloc(sizeof(NoLista));
    l->cau = (NoLista*) malloc(sizeof(NoLista));
    l->cab->prox = l->cau;
    l->cau->prox = NULL;
}

void inserirElementoInicio(Lista* l, Noticia v) {
    NoLista* novo = (NoLista*) malloc(sizeof(NoLista));
    if (novo != NULL) {
        novo->info = v;
        novo->prox = l->cab->prox;
        l->cab->prox = novo;
        }
}

void imprimirNoticia(Lista* l) {
    if(!estaVazia(l)) {
        NoLista* p;
        for(p = l->cab->prox; p != l->cau; p = p->prox) {
            printf("ID: %d\n", p->info.id);
            printf("Data: %d/%d/%d\n", p->info.data.dia, p->info.data.mes, p->info.data.ano);
            printf("Titulo: %s", p->info.titulo);
            printf("Conteudo: %s", p->info.conteudo);
            printf("Fonte: %s\n", p->info.fonte);
        }
    } else {
        printf("Nenhuma noticia pendente cadastrada.\n");
    }
}

void removerPendentePorID(Lista* l, int id) {
    if(!estaVazia(l)) {
        NoLista* p;
        for(p = l->cab; p->prox != l->cau; p = p->prox) {
            if(p->prox->info.id == id) {
                NoLista* temp =p->prox;
                p->prox = p->prox->prox;
                free(temp);
                printf("Noticia de ID: %d removida com sucesso!\n", id);
                return;
                }
            }
        printf("ID %d nao encontrado na lista de pendentes.\n", id);
    } else {
        printf("Lista vazia ou ja removida.\n");
    }
}

void buscarPendentePorPalavraChave(Lista* l, char* palavraBusca) {
    if(!estaVazia(l)) {
        NoLista* p;
        int achou = 0;
        printf("<RESULTADOS DA BUSCA POR '%s'>\n", palavraBusca);
        for(p = l->cab->prox; p != l->cau; p = p->prox) {
            if (strstr(p->info.titulo, palavraBusca) != NULL || strstr(p->info.conteudo, palavraBusca) != NULL) {
                printf("ID: %d\n", p->info.id);
                printf("Titulo: %s", p->info.titulo);
                printf("Conteudo: %s", p->info.conteudo);
                printf("Fonte: %s\n", p->info.fonte);
                achou = 1;
            }
        }
        if (!achou) {
            printf("Nenhuma noticia pendente contem a palavra-chave informada.\n"); 
        }
    } else {
        printf("A lista de pendentes esta vazia.\n");
    }
}

int contarPendentes(Lista* l) {
    if(estaVazia(l)) return 0;
    int cont = 0;
    NoLista* p;
    for(p = l->cab->prox; p != l->cau; p = p->prox) {
        cont++;
    }
    return cont;
}

Noticia* desvincularPendentePorID(Lista* l, int id) {
    if(estaVazia(l)) return NULL;
    NoLista* p;
    for (p = l->cab; p->prox != l->cau; p = p->prox) {
        if (p->prox->info.id == id) {
            NoLista* temp = p->prox;
            p->prox= p->prox->prox;
            Noticia* noticiaExtraida = (Noticia*) malloc(sizeof(Noticia));
            if (noticiaExtraida != NULL) {
                *noticiaExtraida = temp->info;
            }
            free(temp);
            return noticiaExtraida;
        }
    }
    return NULL;
}

void salvarListaPendentes(Lista* l) {
    FILE* f = fopen("pendentes.txt", "w");
    if (f == NULL) return;

    NoLista* p;
    for (p = l->cab->prox; p != l->cau; p = p->prox) {
        fprintf(f, "%d\n", p->info.id);
        fprintf(f, "%d\n", p->info.classificacao);
        fprintf(f, "%s", p->info.titulo); // Já vem com \n do fgets
        fprintf(f, "%s", p->info.conteudo); // Já vem com \n do fgets
        fprintf(f, "%s", p->info.fonte); // Já vem com \n do fgets
        fprintf(f, "%d %d %d\n", p->info.data.dia, p->info.data.mes, p->info.data.ano);
    }
    fclose(f);
}

void carregarListaPendentes(Lista* l, int* maiorId) {
    FILE* f = fopen("pendentes.txt", "r");
    if (f == NULL) return;

    Noticia n;
    while (fscanf(f, "%d\n", &n.id) == 1) {
        if (n.id > *maiorId) {
            *maiorId = n.id;
        }
        fscanf(f, "%d\n", &n.classificacao);
        fgets(n.titulo, 200, f);
        fgets(n.conteudo, 5000, f);
        fgets(n.fonte, 200, f);
        fscanf(f, "%d %d %d\n", &n.data.dia, &n.data.mes, &n.data.ano);

        inserirElementoInicio(l, n);
    }
    fclose(f);
}