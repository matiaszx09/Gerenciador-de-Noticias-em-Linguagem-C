#ifndef LISTACABCAU_H
#define LISTACABCAU_H
#include "Noticia.h"

typedef struct noLista {
    Noticia info;
    struct noLista* prox;
} NoLista;

typedef struct lista {
    NoLista* cab, *cau;
} Lista;

int estaVazia(Lista* l);
void inicializarLista(Lista* l);
void inserirElementoInicio(Lista* l, Noticia v);
void imprimirNoticia(Lista* l);
void removerPendentePorID(Lista* l, int id);
void buscarPendentePorPalavraChave(Lista* l, char* palavraBusca);
int contarPendentes(Lista* l);
Noticia* desvincularPendentePorID(Lista* l, int id);
void salvarListaPendentes(Lista* l);
void carregarListaPendentes(Lista* l, int* maiorId);

#endif